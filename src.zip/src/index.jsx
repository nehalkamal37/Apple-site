// src/index.jsx
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './i18n';           // <- importa la configuración

ReactDOM.render(<App />, document.getElementById('root'));
